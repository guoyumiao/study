package com.yumiao.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yumiao.util.HttpClientUtil;

/**
 * Servlet Filter implementation class SSOLoginFilter
 */
@WebFilter("/*")
public class SSOLoginFilter implements Filter {

    /**
     * Default constructor. 
     */
    public SSOLoginFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain chain) throws IOException, ServletException {
		
		HttpServletRequest request = (HttpServletRequest)servletRequest;
		HttpServletResponse response = (HttpServletResponse)servletResponse;
		String requestURL = request.getRequestURL().toString();
		String token = (String)request.getSession().getAttribute("token");
		if(token == null || "".equals(token)){
			token = (String)request.getParameter("token");
		}
		
		if(token == null || "".equals(token)){
			response.sendRedirect("http://localhost:8080/ssoserver/loginServlet?requestURL=" + requestURL);
			return;
		}
		String json= "";
		String url = "http://localhost:8080/ssoserver/SSOServerServlet?token=" + token;
		String result = HttpClientUtil.doPost(url, json);
		if(result == null || "".equals(result)){
			request.getSession().removeAttribute("token");
			response.sendRedirect("http://localhost:8080/ssoserver/loginServlet?requestURL=" + requestURL);
			return;
		}else{
			request.getSession().setAttribute("token", token);
		}
		chain.doFilter(request, response);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
