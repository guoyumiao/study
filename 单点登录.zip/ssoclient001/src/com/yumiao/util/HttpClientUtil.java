package com.yumiao.util;

import java.io.IOException;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.RequestEntity;
import org.apache.commons.httpclient.methods.StringRequestEntity;

public class HttpClientUtil {

	
	public static String doPost(String url,String json){
        String response="";
      

        //创建HttpClient对象
        HttpClient httpClient = new HttpClient();
        httpClient.getHttpConnectionManager().getParams().setConnectionTimeout(50000); // 连接5秒超时
        httpClient.getHttpConnectionManager().getParams().setSoTimeout(70000);// 读取30秒超时
  
        //通过PostMethod来创建链接,生成一个post请求
        PostMethod method=new PostMethod(url);
        try {

             RequestEntity r=new StringRequestEntity(json);
            //RequestBody或是RequestEntity作用是提供传参，
            //method.setRequestBody(json);//只对整个body
            method.setRequestEntity(r);//可以是分段的内容，RequestEntity是一个接口，有很多实现可以传递不同类型的的参数
            //允许客户端或服务器中任何一方关闭底层的连接双方都会要求在处理请求后关闭它们的TCP连接
            method.setRequestHeader("Connection", "close");
            method.setRequestHeader("Content-type", "application/json; charset=UTF-8");
            //通过httpClient实例里的方法来实例化method
            httpClient.executeMethod(method);
            //读 response,返回的结果
            response = method.getResponseBodyAsString();
            System.out.println(response);
        } catch (HttpException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            //释放链接
            method.releaseConnection();
        }    
        return response;
    }
}
