package com.yumiao.util;

import redis.clients.jedis.Jedis;

public class JedisUtil {

	public static Jedis getJedis(){
		return new Jedis("192.168.1.125", 6379);
	}
	
	public static void main(String[] args) {
		System.out.println(getJedis().get("xiaoli"));
	}
	
}
