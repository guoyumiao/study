package com.yumiao.servlet;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yumiao.util.JedisUtil;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/loginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String requestURL = request.getParameter("requestURL");
		if(requestURL != null && (!"".equals(requestURL))){
			request.getSession().setAttribute("requestURL", requestURL);
		}
		request.getRequestDispatcher("login.jsp").forward(request, response);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String requestURL = (String)request.getSession().getAttribute("requestURL");
		String sessionId = request.getSession().getId();
		String uuid = UUID.randomUUID().toString().replace("-", "").toLowerCase();
		JedisUtil.getJedis().set(uuid, sessionId, "NX", "EX", 60);
		if(requestURL != null && (!"".equals(requestURL))){
			response.sendRedirect(requestURL+"?token="+uuid);
		}
	}

}
